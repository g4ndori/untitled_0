#베이직_25/06/05

import pygame
import random
import time
pygame.init()

size = [400, 700]
screen = pygame.display.set_mode(size)
pygame.display.set_caption("날아라 김 형 준")
clock = pygame.time.Clock()

class objc:
    def __init__(self):
        self.x = 0
        self.y = 0
        self.move = 0
    def put_img(self, cd1):
        if cd1[-3:] == "png":
            self.img = pygame.image.load(cd1).convert_alpha()
        else:
            self.img = pygame.image.load(cd1)
        self.sx, self.sy = self.img.get_size()
    def change_size(self, sx, sy):
        self.img = pygame.transform.scale(self.img, (sx, sy))
        self.sx, self.sy = self.img.get_size()
    def show(self):
        screen.blit(self.img, (self.x, self.y))
def crash(a, b):
    if (a.x-b.sx <= b.x) and (b.x <= a.x+a.sx):
        if (a.y-b.sy <= b.y) and (b.y <= a.y+a.sy):
            return True
        else:
            return False
    else:
        return False  

ufo = objc()
ufo.put_img("ufo_shit1.png")
ufo.change_size(60, 90)
ufo.x = round(size[0] / 2 - ufo.sx / 2)
ufo.y = size[1] - ufo.sy - 50
ufo.move = 4

bomb_img = pygame.image.load("bombb.png").convert_alpha()
bomb_img = pygame.transform.scale(bomb_img, (5, 15))
bomb_size = bomb_img.get_size()

enm_img = pygame.image.load("enm.png").convert_alpha()
enm_img = pygame.transform.scale(enm_img, (40, 40))
enm_size = enm_img.get_size()

leftMov = False
rightMov = False
shott = False

bombList = []
enList = []

Black = (0, 0, 0)

shot_cooldown = 150
last_shot_time = 0

MainEv = 0
while MainEv == 0:
    clock.tick(60)
    current_time = pygame.time.get_ticks()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            MainEv = 1
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                leftMov = True
            elif event.key == pygame.K_RIGHT:
                rightMov = True
            elif event.key == pygame.K_SPACE:
                shott = True
        elif event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT:
                leftMov = False
            elif event.key == pygame.K_RIGHT:
                rightMov = False
            elif event.key == pygame.K_SPACE:
                shott = False

    if leftMov:
        ufo.x -= ufo.move
        if ufo.x <= 0:
            ufo.x = 0
    elif rightMov:
        ufo.x += ufo.move
        if ufo.x >= size[0] - ufo.sx:
            ufo.x = size[0] - ufo.sx

    if shott and current_time - last_shot_time > shot_cooldown:
        bm = objc()
        bm.img = bomb_img
        bm.sx, bm.sy = bomb_size
        bm.x = round(ufo.x + ufo.sx / 2 - bm.sx / 2)
        bm.y = ufo.y - bm.sy - 10
        bm.move = 20
        bombList.append(bm)
        last_shot_time = current_time

    for i in range(len(bombList) - 1, -1, -1):
        bomb = bombList[i]
        bomb.y -= bomb.move
        if bomb.y <= -bomb.sy:
            del bombList[i]

    if random.random() > 0.98:
        en = objc()
        en.img = enm_img
        en.sx, en.sy = enm_size
        en.x = random.randrange(0, size[0] - en.sx)
        en.y = 10
        en.move = 1
        enList.append(en)

    for i in range(len(enList) - 1, -1, -1):
        enm = enList[i]
        enm.y += enm.move
        if enm.y >= size[1]:
            del enList[i]

    dbombList = []
    denmList = []
    for i in range(len(bombList)):
        for j in range(len(enList)):
            bomb = bombList[i]
            enm = enList[j]
            if crash(bomb, enm) == True:
                dbombList.append(i)
                denmList.append(j)
    dbombList = list(set(dbombList))
    denmList = list(set(denmList))

    for db in dbombList:
        del bombList[db]
    for de in denmList:
        del enList[de]
            
    for i in range(len(enList)):
        enm = enList[i]
        if crash(ufo, enm) == True:
            MainEv = 1

    screen.fill(Black)
    ufo.show()
    for bomb in bombList:
        bomb.show()
    for enm in enList:
        enm.show()
    pygame.display.update()

pygame.quit()
