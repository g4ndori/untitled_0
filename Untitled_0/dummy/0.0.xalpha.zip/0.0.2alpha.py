#아이템기능 추가_25/06/06

import pygame
import random
pygame.init()

size = [400, 700]
screen = pygame.display.set_mode(size)
pygame.display.set_caption("날아라 김 형 준")
clock = pygame.time.Clock()

class objc:
    def __init__(self):
        self.x = 0
        self.y = 0
        self.move = 0
    def put_img(self, cd1):
        if cd1[-3:] == "png":
            self.img = pygame.image.load(cd1).convert_alpha()
        else:
            self.img = pygame.image.load(cd1)
        self.sx, self.sy = self.img.get_size()
    def change_size(self, sx, sy):
        self.img = pygame.transform.scale(self.img, (sx, sy))
        self.sx, self.sy = self.img.get_size()
    def show(self):
        screen.blit(self.img, (self.x, self.y))
def crash(a, b):
    if (a.x - b.sx <= b.x) and (b.x <= a.x + a.sx):
        if (a.y - b.sy <= b.y) and (b.y <= a.y + a.sy):
            return True
    return False  

font = pygame.font.SysFont("malgungothic", 30)

def draw_menu():
    screen.fill((0, 0, 0))
    title_text = "날아라 김 형 준"
    start_text = "ENTER를 눌러 게임 시작"
    control_text = "← → : 이동 | 스페이스 : 발사"

    title = font.render(title_text, True, (255, 255, 255))
    start_msg = font.render(start_text, True, (255, 255, 255))
    control_msg = font.render(control_text, True, (180, 180, 180))

    title_rect = title.get_rect(center=(size[0] // 2, size[1] // 2 - 60))
    start_rect = start_msg.get_rect(center=(size[0] // 2, size[1] // 2))
    control_rect = control_msg.get_rect(center=(size[0] // 2, size[1] // 2 + 40))

    screen.blit(title, title_rect)
    screen.blit(start_msg, start_rect)
    screen.blit(control_msg, control_rect)
    pygame.display.update()

def draw_health_bar(obj):
    bar_width = obj.sx
    bar_height = 5
    health_ratio = max(obj.hp / obj.max_hp, 0)
    pygame.draw.rect(screen, (255, 0, 0), (obj.x, obj.y + obj.sy + 2, bar_width, bar_height))
    pygame.draw.rect(screen, (0, 255, 0), (obj.x, obj.y + obj.sy + 2, bar_width * health_ratio, bar_height))

game_started = False
running = True

while not game_started and running:
    draw_menu()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_RETURN:
                game_started = True

if not running:
    pygame.quit()
    exit()

ufo = objc()
ufo.put_img("ufo_shit1.png")
ufo.change_size(60, 90)
ufo.x = round(size[0] / 2 - ufo.sx / 2)
ufo.y = size[1] - ufo.sy - 50
ufo.move = 4

bomb_img = pygame.image.load("bombb.png").convert_alpha()
bomb_img = pygame.transform.scale(bomb_img, (5, 15))
bomb_size = bomb_img.get_size()

enm_img = pygame.image.load("enm.png").convert_alpha()
enm_img = pygame.transform.scale(enm_img, (40, 40))
enm_size = enm_img.get_size()

item_img = pygame.image.load("item.png").convert_alpha()
item_img = pygame.transform.scale(item_img, (30, 30))

leftMov = False
rightMov = False
shott = False

bombList = []
enList = []
itemList = []

Black = (0, 0, 0)

shot_cooldown = 150
last_shot_time = 0
bomb_shot_count = 1

start_ticks = pygame.time.get_ticks()

MainEv = 0
while MainEv == 0:
    clock.tick(60)
    current_time = pygame.time.get_ticks()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            MainEv = 1
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                leftMov = True
            elif event.key == pygame.K_RIGHT:
                rightMov = True
            elif event.key == pygame.K_SPACE:
                shott = True
        elif event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT:
                leftMov = False
            elif event.key == pygame.K_RIGHT:
                rightMov = False
            elif event.key == pygame.K_SPACE:
                shott = False

    if leftMov:
        ufo.x -= ufo.move
        if ufo.x <= 0:
            ufo.x = 0
    elif rightMov:
        ufo.x += ufo.move
        if ufo.x >= size[0] - ufo.sx:
            ufo.x = size[0] - ufo.sx

    if shott and current_time - last_shot_time > shot_cooldown:
        for i in range(bomb_shot_count):
            bm = objc()
            bm.img = bomb_img
            bm.sx, bm.sy = bomb_size
            bm.x = round(ufo.x + ufo.sx / 2 - bm.sx / 2 + (i - bomb_shot_count//2) * (bm.sx + 2))
            bm.y = ufo.y - bm.sy - 10
            bm.move = 20
            bombList.append(bm)
        last_shot_time = current_time

    for i in range(len(bombList) - 1, -1, -1):
        bomb = bombList[i]
        bomb.y -= bomb.move
        if bomb.y <= -bomb.sy:
            del bombList[i]

    elapsed_seconds = (pygame.time.get_ticks() - start_ticks) / 1000
    base_spawn_chance = 0.005
    max_spawn_chance = 0.05
    enemy_spawn_chance = min(base_spawn_chance + elapsed_seconds * 0.002, max_spawn_chance)

    if random.random() < enemy_spawn_chance:
        en = objc()
        en.img = enm_img
        en.sx, en.sy = enm_size
        en.x = random.randrange(0, size[0] - en.sx)
        en.y = 10
        en.move = 1
        en.hp = 6
        en.max_hp = 6
        enList.append(en)

    if random.random() > 0.9995:
        it = objc()
        it.img = item_img
        it.sx, it.sy = item_img.get_size()
        it.x = random.randrange(0, size[0] - it.sx)
        it.y = 10
        it.move = 2
        itemList.append(it)

    for i in range(len(enList) - 1, -1, -1):
        enm = enList[i]
        enm.y += enm.move
        if enm.y >= size[1]:
            del enList[i]

    for i in range(len(itemList) - 1, -1, -1):
        item = itemList[i]
        item.y += item.move
        if item.y >= size[1]:
            del itemList[i]

    dbombList = []
    denmList = []
    for i in range(len(bombList)):
        for j in range(len(enList)):
            bomb = bombList[i]
            enm = enList[j]
            if crash(bomb, enm):
                enm.hp -= 2
                dbombList.append(i)
                if enm.hp <= 0:
                    denmList.append(j)
    dbombList = list(set(dbombList))
    denmList = list(set(denmList))

    for db in sorted(dbombList, reverse=True):
        del bombList[db]
    for de in sorted(denmList, reverse=True):
        del enList[de]

    for enm in enList:
        if crash(ufo, enm):
            MainEv = 1
            break

    del_item_indexes = []
    for i, item in enumerate(itemList):
        if crash(ufo, item):
            bomb_shot_count += 1
            del_item_indexes.append(i)
    for idx in sorted(del_item_indexes, reverse=True):
        del itemList[idx]

    screen.fill(Black)
    ufo.show()
    for bomb in bombList:
        bomb.show()
    for enm in enList:
        enm.show()
        draw_health_bar(enm)
    for item in itemList:
        item.show()
    pygame.display.update()

pygame.quit()
