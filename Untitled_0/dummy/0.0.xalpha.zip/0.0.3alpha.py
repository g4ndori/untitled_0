#상점기능&게임오버 추가

import pygame
import random
from pydub import AudioSegment

pygame.mixer.pre_init(44100, -16, 2, 512)
pygame.init()
pygame.mixer.init()

size = [400, 700]
screen = pygame.display.set_mode(size)
pygame.display.set_caption("날아라 김 형 준")
clock = pygame.time.Clock()

class objc:
    def __init__(self):
        self.x = 0
        self.y = 0
        self.move = 0
    def put_img(self, cd1):
        if cd1[-3:] == "png":
            self.img = pygame.image.load(cd1).convert_alpha()
        else:
            self.img = pygame.image.load(cd1)
        self.sx, self.sy = self.img.get_size()
    def change_size(self, sx, sy):
        self.img = pygame.transform.scale(self.img, (sx, sy))
        self.sx, self.sy = self.img.get_size()
    def show(self):
        screen.blit(self.img, (self.x, self.y))

def crash(a, b):
    rect_a = pygame.Rect(a.x, a.y, a.sx, a.sy)
    rect_b = pygame.Rect(b.x, b.y, b.sx, b.sy)
    return rect_a.colliderect(rect_b)

font = pygame.font.SysFont("malgungothic", 15)
large_font = pygame.font.SysFont("malgungothic", 30)

def draw_menu():
    screen.fill((0, 0, 0))
    title = font.render("날아라 김 형 준", True, (255, 255, 255))
    start_msg = font.render("ENTER를 눌러 게임 시작", True, (255, 255, 255))
    control_msg = font.render("← → : 이동 | 스페이스 : 발사", True, (180, 180, 180))
    screen.blit(title, (100, 250))
    screen.blit(start_msg, (80, 300))
    screen.blit(control_msg, (80, 330))
    pygame.display.update()

def draw_health_bar(obj):
    bar_width = obj.sx
    bar_height = 5
    health_ratio = max(obj.hp / obj.max_hp, 0)
    pygame.draw.rect(screen, (255, 0, 0), (obj.x, obj.y + obj.sy + 2, bar_width, bar_height))
    pygame.draw.rect(screen, (0, 255, 0), (obj.x, obj.y + obj.sy + 2, bar_width * health_ratio, bar_height))

def game_over_screen(kill_count, gold):
    button_restart = pygame.Rect(100, 400, 200, 50)
    button_exit = pygame.Rect(100, 470, 200, 50)
    while True:
        screen.fill((30, 30, 30))
        title = large_font.render("게임 오버", True, (255, 0, 0))
        kills = font.render(f"적 처치 수: {kill_count}", True, (255, 255, 255))
        gold_text = font.render(f"획득 골드: {gold}", True, (255, 255, 0))
        pygame.draw.rect(screen, (100, 100, 100), button_restart)
        pygame.draw.rect(screen, (100, 100, 100), button_exit)
        restart_text = font.render("다시 시작", True, (255, 255, 255))
        exit_text = font.render("게임 종료", True, (255, 255, 255))
        screen.blit(title, (130, 200))
        screen.blit(kills, (130, 250))
        screen.blit(gold_text, (130, 280))
        screen.blit(restart_text, (160, 415))
        screen.blit(exit_text, (160, 485))
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if button_restart.collidepoint(event.pos):
                    return True
                elif button_exit.collidepoint(event.pos):
                    pygame.quit()
                    exit()

def main():
    game_started = False
    running = True
    while not game_started and running:
        draw_menu()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    game_started = True
    if not running:
        pygame.quit()
        return

    while True:
        ufo = objc()
        ufo.put_img("ufo_shit1.png")
        ufo.change_size(60, 90)
        ufo.x = round(size[0] / 2 - ufo.sx / 2)
        ufo.y = size[1] - ufo.sy - 50
        ufo.move = 4

        bomb_img = pygame.image.load("bombb.png").convert_alpha()
        bomb_img = pygame.transform.scale(bomb_img, (5, 15))
        bomb_size = bomb_img.get_size()

        enm_img = pygame.image.load("enm.png").convert_alpha()
        enm_img = pygame.transform.scale(enm_img, (40, 40))
        enm_size = enm_img.get_size()

        shield_img = pygame.image.load("shield1.png").convert_alpha()
        shield_img = pygame.transform.scale(shield_img, (ufo.sx + 10, ufo.sy + 10))

        leftMov = False
        rightMov = False
        shott = False

        bombList = []
        enList = []
        itemList = []
        damage_texts = []

        shot_cooldown = 150
        last_shot_time = 0
        bomb_shot_count = 1
        gold = 0
        shield_active = False
        double_shot = False
        shop_open = False

        kill_count = 0

        start_ticks = pygame.time.get_ticks()

        MainEv = 0
        while MainEv == 0:
            clock.tick(60)
            current_time = pygame.time.get_ticks()

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    exit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_LEFT:
                        leftMov = True
                    elif event.key == pygame.K_RIGHT:
                        rightMov = True
                    elif event.key == pygame.K_SPACE:
                        shott = True
                    elif event.key == pygame.K_s:
                        shop_open = not shop_open
                    elif shop_open:
                        if event.key == pygame.K_1 and gold >= 100:
                            double_shot = True
                            gold -= 100
                        elif event.key == pygame.K_2 and gold >= 1000:
                            shield_active = True
                            gold -= 1000
                elif event.type == pygame.KEYUP:
                    if event.key == pygame.K_LEFT:
                        leftMov = False
                    elif event.key == pygame.K_RIGHT:
                        rightMov = False
                    elif event.key == pygame.K_SPACE:
                        shott = False

            if shop_open:
                screen.fill((30, 30, 30))
                shop_title = font.render("상점 (S로 닫기)", True, (255, 255, 255))
                item1 = font.render("1. 더블샷 (100G)", True, (255, 255, 255))
                item2 = font.render("2. 보호막 (1000G)", True, (255, 255, 255))
                player_gold = font.render(f"현재 G: {gold}", True, (255, 255, 0))
                screen.blit(shop_title, (100, 100))
                screen.blit(item1, (100, 130))
                screen.blit(item2, (100, 160))
                screen.blit(player_gold, (100, 200))
                pygame.display.update()
                continue

            if leftMov:
                ufo.x -= ufo.move
                if ufo.x < 0:
                    ufo.x = 0
            if rightMov:
                ufo.x += ufo.move
                if ufo.x > size[0] - ufo.sx:
                    ufo.x = size[0] - ufo.sx

            if shott and current_time - last_shot_time > shot_cooldown:
                bullet_count = 2 if double_shot else 1
                for i in range(bullet_count):
                    bm = objc()
                    bm.img = bomb_img
                    bm.sx, bm.sy = bomb_size
                    offset = (i - (bullet_count - 1) / 2) * (bm.sx + 2)
                    bm.x = round(ufo.x + ufo.sx / 2 - bm.sx / 2 + offset)
                    bm.y = ufo.y - bm.sy - 10
                    bm.move = 20
                    bombList.append(bm)
                last_shot_time = current_time

            for i in range(len(bombList) - 1, -1, -1):
                bomb = bombList[i]
                bomb.y -= bomb.move
                if bomb.y < -bomb.sy:
                    del bombList[i]

            elapsed_seconds = (pygame.time.get_ticks() - start_ticks) / 1000
            enemy_spawn_chance = min(0.005 + elapsed_seconds * 0.002, 0.05)

            if random.random() < enemy_spawn_chance:
                en = objc()
                en.img = enm_img
                en.sx, en.sy = enm_size
                en.x = random.randrange(0, size[0] - en.sx)
                en.y = 10
                en.move = 1
                en.hp = 6
                en.max_hp = 6
                enList.append(en)

            for i in range(len(enList) - 1, -1, -1):
                enList[i].y += enList[i].move
                if enList[i].y > size[1]:
                    del enList[i]

            dbombList = []
            denmList = []
            for i in range(len(bombList)):
                for j in range(len(enList)):
                    bomb = bombList[i]
                    enm = enList[j]
                    if crash(bomb, enm):
                        enm.hp -= 2
                        dbombList.append(i)
                        if enm.hp <= 0:
                            denmList.append(j)
                            gained_gold = random.randrange(1, 20)
                            gold += gained_gold
                            kill_count += 1
                            damage_texts.append((enm.x, enm.y, pygame.time.get_ticks(), gained_gold))

            dbombList = list(set(dbombList))
            denmList = list(set(denmList))
            for db in sorted(dbombList, reverse=True):
                if db < len(bombList):
                    del bombList[db]
            for de in sorted(denmList, reverse=True):
                if de < len(enList):
                    del enList[de]

            for enm in enList:
                if crash(ufo, enm):
                    if shield_active:
                        shield_active = False
                        enList.remove(enm)
                        break
                    else:
                        MainEv = 1
                        break

            screen.fill((0, 0, 0))
            ufo.show()
            if shield_active:
                screen.blit(shield_img, (ufo.x - 5, ufo.y - 5))
            for bomb in bombList:
                bomb.show()
            for enm in enList:
                enm.show()
                draw_health_bar(enm)

            gold_text = font.render(f"G : {gold}", True, (255, 255, 255))
            screen.blit(gold_text, (10, 10))

            for entry in damage_texts[:]:
                x, y, start_time, gained = entry
                if pygame.time.get_ticks() - start_time < 1000:
                    dmg_text = font.render(f"+{gained}G", True, (255, 255, 0))
                    screen.blit(dmg_text, (x, y))
                else:
                    damage_texts.remove(entry)

            pygame.display.update()

        restart = game_over_screen(kill_count, gold)
        if not restart:
            break

main()
